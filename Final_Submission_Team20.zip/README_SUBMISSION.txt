PROJECT SUBMISSION: COMPUTER NETWORK SECURITY
Title: False Data Injection Attack Detection in EV Charging Network Using NARX Neural Network
Team No: 20

Authors / Group Members:
1. Sumit Kumar (Roll No: CS23B2008)
2. Nisarg Rande (Roll No: CS23B1090)
3. Jatin Goyal (Roll No: CS23B2045)

Department: Department of Computer Science and Engineering
Institution: Indian Institute of Information Technology Design and Manufacturing (IIITDM)
Faculty Advisor: Dr. Pradeep Kumar Bhale

Contents of this Submission Archive:
1. IEEE_Final_Paper.pdf       - Final 5-page IEEE two-column paper (complies with Turnitin <20%)
2. Overleaf_Project.zip       - Standalone Overleaf project archive (upload directly to Overleaf)
3. main.tex                   - LaTeX source document (IEEEtran conference class)
4. references.bib             - Complete BibTeX citation database
5. images/                    - High-resolution figures (300 DPI)
   - fig1_flowchart.png       (End-to-end system architecture & attack flow)
   - fig2_attack_iqr.png       (Energy estimation & consecutive spike IQR detection)
   - fig3_comparison.png       (Performance comparison bar chart)
   - fig4_opal_rt.png          (OPAL-RT real-time hardware validation & scope waveform)
